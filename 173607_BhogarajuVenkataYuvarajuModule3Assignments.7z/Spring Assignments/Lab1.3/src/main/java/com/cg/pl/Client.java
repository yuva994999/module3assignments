package com.cg.pl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cg.bean.SBU;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("Emp.xml");
		SBU sbu=(SBU) applicationContext.getBean("SBU");
		System.out.println(sbu);
	}

}
