package com.cg.bean;

public class Trainee {

}
