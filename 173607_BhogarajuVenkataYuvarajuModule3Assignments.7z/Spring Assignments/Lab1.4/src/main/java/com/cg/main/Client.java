package com.cg.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;
import com.cg.service.EmployeeService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("Emp.xml");
		EmployeeService emp=(EmployeeService) applicationContext.getBean("employeeservice");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the employee ID to get Details: ");
		int eid=sc.nextInt();
		System.out.println(emp.getEmpbyId(eid).printDetails());
	}

}
