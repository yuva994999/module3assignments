package com.cg.dao;

import java.util.Map;

import com.cg.bean.Employee;

public class EmployeeDao {
Map<Integer,Employee> mp;
public Map<Integer, Employee> getMp() {
	return mp;
}
public void setMp(Map<Integer, Employee> mp) {
	this.mp = mp;
}

public Employee getEmpDetailsbyId(int eid)
{
	mp.get(eid);
	return mp.get(eid);
}
}
