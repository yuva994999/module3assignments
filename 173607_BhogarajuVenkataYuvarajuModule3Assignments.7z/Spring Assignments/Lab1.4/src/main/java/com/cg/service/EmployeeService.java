package com.cg.service;



import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;

public class EmployeeService {
	EmployeeDao dao;
	
	
   public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}


public Employee getEmpbyId(int eid)
   {
	   dao.getEmpDetailsbyId(eid);
	return dao.getEmpDetailsbyId(eid);
   }
}
