package com.cg.bean;

public class Employee {
	private int employeeId;
	private String employeeName;
	private double salary;
	private SBU businessunit;
	private int age;

	public Employee(SBU businessunit) {
		// TODO Auto-generated constructor stub
		this.businessunit=businessunit;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public SBU getBusinessunit() {
		return businessunit;
	}

	public void setBusinessunit(SBU businessunit) {
		this.businessunit = businessunit;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", businessunit=" + businessunit + ", age=" + age + "]";
	}
	
	
}
