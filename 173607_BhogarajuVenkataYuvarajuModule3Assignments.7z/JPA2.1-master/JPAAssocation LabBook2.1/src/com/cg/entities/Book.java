package com.cg.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

import com.cg.entities.Author;

@Entity
@Table(name="book")
public class Book implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private int ISBN;
	private String title;
	private double price;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "book_author", joinColumns =
{ @JoinColumn(name = "book_isbnid") }, inverseJoinColumns =
	{@JoinColumn(name = "author_id") })
	private Set<Author> author = new HashSet<>();	
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Set<Author> getAuthor() {
		return author;
	}
	public void setAuthor(Set<Author> author) {
		this.author = author;
	}
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		this.getAuthor().add(author);
		
	}

	
}
